V0.27
1、Added a single PTT mode, which can be toggled on/off via the menu.
2、Added a temporary scan list feature, which can be custom-mapped to long-pressing keys 0–9.
3、Add channel scanning with add and delete set functions

V0.28
1. Fix the crash bug in the scanning and addition function under the zone mode

V0.29
1、Updated the spectrum interface and fixed related bugs.
2、Optimized spectrum functionality: added 5 kHz stepping and backlight-off option.
3、Enabled independent configuration of PF1 and PTTC functions.
4、Added menus for DTMF code-delay, code-duration, and inter-code spacing.
5、Added the ability to customize zone names.
6、Improved stability to prevent APRS crashes.